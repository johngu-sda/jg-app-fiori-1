sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("jgapp1.jgappfiori1.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map